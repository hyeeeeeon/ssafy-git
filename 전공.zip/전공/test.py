from openai import OpenAI

client = OpenAI(
  api_key="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"
)

response = client.responses.create(
  model="gpt-5.4-mini",
  input="write a haiku about ai",
  store=True,
)

print(response.output_text);

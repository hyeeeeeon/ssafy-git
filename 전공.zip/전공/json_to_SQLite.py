import json
import sqlite3

conn = sqlite3.connect("data/Ddata.db")
cursor = conn.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS leprots (
        contentid string 
        contenttypeid string 
        title string 
        addr1 string 
        addr2 string
        zipcode string
        tel string
        mapx string
        mapy string
        mlevel string
        areacode string
        sigungucode string
        lDongRegnCd string
        lDongSignguCd string
        cat1 string
        cat2 string
        cat3 string
        lclsSystm1 string
        lclsSystm2 string
        lclsSystm3 string
        firstimage string
        firstimage2 strin
        cpyrhtDivCd string
        createdtime string
        modifiedtime string 
    )
""")

with open("data/대전_충청권/대전_충청권_레포츠.json", encoding="utf-8") as f:
    data = json.load(f)

for item in data["items"]:
    cursor.execute("""
        INSERT INTO leprots (contentid, 
        contenttypeid,  
        title, 
        addr1, 
        addr2,
        zipcode,
        tel,
        mapx,
        mapy,
        mlevel,
        areacode,
        sigungucode,
        lDongRegnCd, 
        lDongSignguCd,
        cat1,
        cat2, 
        cat3,
        lclsSystm1, 
        lclsSystm2, 
        lclsSystm3, 
        firstimage,
        firstimage2,
        cpyrhtDivCd, 
        createdtime, 
        modifiedtime)
        VALUES (?, ?, ?, ?)
    """, (item["필드1"], item["필드2"], item["필드3"], item["필드4"]))

conn.commit()
conn.close()
import json

with open("data/대전_충청권/대전_충청권_관광지.json", encoding="utf-8") as f:
    data = json.load(f)

    print(type(data))  # 타입 dict
    print(len(data))    # 5
    print(data.keys()) # ['region', 'contentType', 'contentTypeId', 'total', 'items']

    print(type(data['items'])) # list
    print(len(data['items'][2]))   # 한 아이템당 목록수 25 -> 모든 파일 동일

'''
| `contentid` | string | 콘텐츠 고유 ID |
| `contenttypeid` | string | 콘텐츠 유형 ID |
| `title` | string | 장소명 |
| `addr1` | string | 주소 (도로명 또는 지번) |
| `addr2` | string | 주소 상세 (건물명 등) |
| `zipcode` | string | 우편번호 |
| `tel` | string | 전화번호 |
| `mapx` | string | 경도 (WGS84) |
| `mapy` | string | 위도 (WGS84) |
| `mlevel` | string | 지도 레벨 |
| `areacode` | string | 지역 코드 |
| `sigungucode` | string | 시군구 코드 |
| `lDongRegnCd` | string | 법정동 지역 코드 |
| `lDongSignguCd` | string | 법정동 시군구 코드 |
| `cat1` | string | 대분류 코드 |
| `cat2` | string | 중분류 코드 |
| `cat3` | string | 소분류 코드 |
| `lclsSystm1` | string | 분류 체계 1 |
| `lclsSystm2` | string | 분류 체계 2 |
| `lclsSystm3` | string | 분류 체계 3 |
| `firstimage` | string | 대표 이미지 URL (원본) |
| `firstimage2` | string | 대표 이미지 URL (썸네일) |
| `cpyrhtDivCd` | string | 저작권 구분 코드 |
| `createdtime` | string | 최초 등록 시각 (YYYYMMDDHHmmss) |
| `modifiedtime` | string | 최종 수정 시각 (YYYYMMDDHHmmss) |

'''